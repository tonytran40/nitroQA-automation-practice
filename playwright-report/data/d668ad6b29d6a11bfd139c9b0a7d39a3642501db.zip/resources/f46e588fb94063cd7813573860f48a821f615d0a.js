import{j as r}from"./playbook-ui-Bo6HcHKg.js";import{c as s}from"./client-R0cmruG7.js";import{A as t}from"./index-CgX5gCa4.js";const e=({children:o})=>r.jsx(t,{client:s,children:o});export{e as P};
//# sourceMappingURL=Provider-DeF7ljVS.js.map
