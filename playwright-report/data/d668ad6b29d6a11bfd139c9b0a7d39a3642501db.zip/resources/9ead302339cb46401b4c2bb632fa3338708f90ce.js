(window.webpackJsonp=window.webpackJsonp||[]).push([[24],{"8MAY":function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),o=a("LvDl"),i=a("lTCR"),l=a.n(i),m=a("OLee");const c=({photo:e,id:t,name:a,territory:n,title:i,active:l})=>r.a.createElement(m.User,{avatar:!0,avatarUrl:l&&Object(o.get)(e,"url",null),id:`option-user-${t}`,name:a,orientation:"horizontal",territory:Object(o.get)(n,"name"),title:Object(o.get)(i,"name")});c.fragments={user:l.a`
    fragment UserOptionEmployee on Employee {
      id
      photo { url }
      name
      territory {
        id
        name
      }
      title {
        id
        name
      }
      active
    }
  `},t.default=c}}]);