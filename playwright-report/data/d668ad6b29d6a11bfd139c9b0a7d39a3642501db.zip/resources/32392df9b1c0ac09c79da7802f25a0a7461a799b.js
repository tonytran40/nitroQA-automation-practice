import{g as o}from"./lodash-D-AsfB3s.js";function n(){}var t=n;const p=o(t);export{t as a,p as n};
//# sourceMappingURL=noop-xAjaGxRJ.js.map
