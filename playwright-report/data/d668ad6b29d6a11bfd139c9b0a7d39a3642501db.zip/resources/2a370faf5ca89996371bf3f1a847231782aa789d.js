import{j as s}from"./playbook-ui-Bo6HcHKg.js";import{I as r}from"./_getTag-CYwN4WGm.js";const e=({size:n="2x",wrapperClass:o=""})=>s.jsx("div",{className:o,children:s.jsx(r,{name:"spinner",size:n,spin:!0})});export{e as L};
//# sourceMappingURL=Loading-74P7U5gZ.js.map
