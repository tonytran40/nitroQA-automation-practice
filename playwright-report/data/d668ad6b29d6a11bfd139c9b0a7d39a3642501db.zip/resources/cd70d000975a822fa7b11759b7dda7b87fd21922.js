import{o as t}from"./_getTag-CYwN4WGm.js";var e=t(Object.getPrototypeOf,Object);export{e as g};
//# sourceMappingURL=_getPrototype-D7-4emVc.js.map
