import{g as a}from"./index-CgX5gCa4.js";const r=a`
  query {
    powerlifeTagRankings {
      id
      nitroTagId
      nitroTagName
      ranking
    }
  }
`,n=a`
  query ($name: String, $created: String) {
    powerlifeTaggings(name: $name, created: $created) {
      id
      tag {
        id
        name
      }
      createdAt
    }
  }
`;export{r as G,n as a};
//# sourceMappingURL=queries-CU2_M8ss.js.map
