import{j as e,d as K,b as l,C as O,f as le,l as I,B as V,e as f,F as G,D as v,T as J,m as w,b6 as ue,E as de,U as me,h as Q,L as pe}from"./playbook-ui-Bo6HcHKg.js";import{u as W,g as j,c as P}from"./index-CgX5gCa4.js";import{l as X}from"./lodash-D-AsfB3s.js";import"./index-DoroZm-V.js";import{c as he}from"./client-R0cmruG7.js";import"./useConnectionQuery-ekxovqlg.js";import{C as xe,E as ge}from"./queries-Cf2FMXHP.js";import{f as fe}from"./fetchers-BWb6OV9g.js";import{s as g}from"./styles.module-a6KsJNCg.js";import{P as Se}from"./Provider-DeF7ljVS.js";import{f as Ce}from"./graphql-aNNXYdaO.js";import"./index-zswDK1xz.js";import"./UserOption-LtQ1jPdz.js";import"./usePermissions-D9MOhVsa.js";import"./index.esm-BB6pL43V.js";import"./directory-CRR2vaK8.js";import"./stimulus-CBB91UyO.js";const je=({formatOptionLabel:r,selectedRoom:s,setSelectedRoom:o})=>{var n;const{data:i}=W(xe),c=(n=i==null?void 0:i.connectRoomSearch)==null?void 0:n.map(t=>({id:t.id,name:t.name})),d={SingleValue:({data:t})=>e.jsx("span",{children:t.name})},u=fe({client:he,playbook:!0,query:j`
      query ($search: Json) {
        options: connectRoomSearch(search: $search) {
          id
          name
        }
      }
    `,variables:t=>({search:{name_cont:t}})});return e.jsx(K,{async:!0,cacheOptions:!1,components:d,formatOptionLabel:r,getOptionLabel:t=>t.name,getOptionValue:({name:t})=>`${t}`,loadOptions:X.debounce(u,350),onChange:t=>o(t),options:c==null?void 0:c.filter(t=>t.name!=(s==null?void 0:s.name)),placeholder:"Select a room..."})};j`
  mutation (
    $postId: ID!
    $type: String!
    $input: BrandHeadlinesPostAssetInput!
  ) {
    uploadPostAssets(postId: $postId, type: $type, input: $input) {
      filename
      url
    }
  }
`;j`
  mutation ($assetId: ID!, $postId: ID!, $type: String!) {
    powerlifeDeletePostAsset(assetId: $assetId, postId: $postId, type: $type) {
      id
      filename
      url
    }
  }
`;j`
  mutation ($postId: ID!, $type: String!, $s3Key: String!) {
    uploadPostVideo(postId: $postId, type: $type, s3Key: $s3Key) {
      filename
      cloudflareStreamVideo {
        identifier
        readyToStream
      }
    }
  }
`;const ye=j`
  mutation ($userId: ID!, $message: String!) {
    connectClientShareToUser(userId: $userId, message: $message)
  }
`,be=j`
  mutation ($roomId: ID!, $message: String!) {
    connectClientShareToRoom(roomId: $roomId, message: $message)
  }
`,Z=j`
  mutation ($input: BrandHeadlinesShareMetricInput!) {
    powerlifeCreateShareMetric(input: $input) {
      id
    }
  }
`,ee=({url:r})=>{const[s,o]=l.useState(!1),i=()=>{navigator.clipboard.writeText(r),o(!0)};return e.jsxs(e.Fragment,{children:[e.jsx(O,{text:"URL"}),e.jsx(le,{padding:"xxs",children:e.jsxs(I,{align:"center",justify:"between",children:[e.jsx(V,{paddingLeft:"xs",text:r}),e.jsx(f,{onClick:i,text:"Copy",variant:"secondary"})]})}),e.jsx(I,{justify:"center",marginTop:"sm",children:e.jsx(G,{closeable:!0,onClose:()=>o(!1),open:s,status:"success",text:"Link copied to clipboard"})})]})},Te=({buildMessage:r,error:s,formatOptionLabel:o,handleMessageText:i,onCancel:c,postId:d,postType:u,selectedRoom:n,setError:t,setConfirmationToast:a,setSelectedRoom:S,setWholeRoom:h,toggleLgDialog:x,url:p,value:k,wholeRoom:y})=>{const[E,{loading:b}]=P(be),[T]=P(Z),B=()=>{n!=null&&n.id?E({variables:{roomId:n.id,message:r()}}).then(()=>{x(!1),a(!0),t(null),T({variables:{input:{postId:d,postType:u}}})}).catch(()=>{t("Failed to share the post. Please try again later or toggle off Notify All Default.")}):t("Please select a room before sending the message.")};return e.jsxs(e.Fragment,{children:[e.jsxs(v.Body,{className:g.ShareMessageBody,children:[s&&e.jsx(O,{color:"error",text:s}),e.jsx(je,{formatOptionLabel:o,selectedRoom:n,setSelectedRoom:S}),e.jsx(O,{text:"Message (Optional)"}),e.jsx(J,{name:"message",onChange:$=>i($),placeholder:"Placeholder text",value:k}),e.jsxs(I,{justify:"between",children:[e.jsxs(w,{children:[e.jsx(O,{text:"NOTIFY ALL ROOM MEMBERS(ON BY DEFAULT)"}),e.jsx(V,{text:"Everyone in the selected room will receive a push notification on Connect"})]}),e.jsx(w,{children:e.jsx(ue,{checked:y,onChange:()=>h($=>!$)})})]}),e.jsx(de,{marginY:"sm"}),e.jsx(ee,{url:p})]}),e.jsxs(v.Footer,{children:[e.jsx(f,{disabled:b,onClick:B,text:"Share"}),e.jsx(f,{onClick:c,text:"Cancel",variant:"link"})]})]})},$e=({imageUrl:r,id:s,name:o,territory:i,title:c,active:d})=>e.jsx(me,{avatar:!0,avatarUrl:d&&r?r:void 0,id:`option-user-${s}`,name:o,orientation:"horizontal",territory:i,title:c},`option-user-${s}`),Oe=({placeholder:r,handleSelectedUser:s})=>{var t;const{data:o}=W(ge),[i,c]=l.useState(),d={SingleValue:({data:a})=>e.jsx("span",{children:a.name})},u=({name:a},{inputValue:S})=>{const h=x=>S.length?x.replace(new RegExp(S,"gi"),p=>`<mark>${p}</mark>`):x;return e.jsx(I,{children:e.jsx(w,{children:e.jsx(Q,{size:4,children:e.jsx("span",{dangerouslySetInnerHTML:{__html:h(a)}})})})})},n=(t=o==null?void 0:o.powerlifeEmployeeSearch)==null?void 0:t.nodes.map(a=>({id:a.id,name:a.name}));return e.jsx(Se,{children:e.jsx(K,{async:!0,cacheOptions:!1,components:d,formatOptionLabel:u,getOptionLabel:a=>a.name,getOptionValue:({name:a})=>`${a}`,loadOptions:X.debounce(Ce({active_eq:!0},!0),350),onChange:a=>{s(a),c(a)},options:n==null?void 0:n.filter(a=>a.name!=(i==null?void 0:i.name)),placeholder:r,valueComponent:$e,zIndex:10})})},Ie=({buildMessage:r,error:s,handleMessageText:o,onCancel:i,postId:c,postType:d,selectedUser:u,setError:n,setConfirmationToast:t,setSelectedUser:a,toggleLgDialog:S,url:h,value:x})=>{const[p,{loading:k}]=P(ye),[y]=P(Z),E=()=>{u!=null&&u.id?p({variables:{userId:u.id,message:r()}}).then(()=>{S(!1),t(!0),n(null),y({variables:{input:{postId:c,postType:d}}})}).catch(()=>{n("Failed to share the post. Please try again later.")}):n("Please select a user before sending the message.")};return e.jsxs(e.Fragment,{children:[e.jsxs(v.Body,{className:g.ShareMessageBody,children:[s&&e.jsx(O,{color:"error",text:s}),e.jsx(Oe,{handleSelectedUser:a,placeholder:"Select a recipient..."}),e.jsx(O,{text:"Message (Optional)"}),e.jsx(J,{name:"message",onChange:b=>o(b),placeholder:"Placeholder text",value:x}),e.jsx(ee,{url:h})]}),e.jsxs(v.Footer,{children:[e.jsx(f,{disabled:k,onClick:E,text:"Share"}),e.jsx(f,{onClick:i,text:"Cancel",variant:"link"})]})]})},te=l.createContext(!1),Ke=({children:r})=>{const s=new Date().getMonth()===9;return e.jsx(te.Provider,{value:s,children:r})},ve=()=>l.useContext(te),ke=(r=!1)=>{const[s,o]=l.useState(r);return[s,()=>o(!s)]},Ve=({bannerImageUrl:r,listView:s,url:o,postId:i,postTitle:c,postType:d,message:u,displayName:n,buttonVariant:t,viewVariant:a})=>{const[S,h]=l.useState(!1),[x,p]=l.useState(null),[k,y]=l.useState(),[E,b]=l.useState(),[T,B]=l.useState(u),[$,R]=l.useState(!0),[H,D]=l.useState(!1),[se,M]=ke(),[U,F]=l.useState(!1),_=ve(),N=()=>{M(!1)},A=()=>{M(!0),B(u),R(!0),D(!1),h(!1),y(null),b(null)},oe=()=>{R(!0),D(!1),F(!1),p(null)},ne=()=>{R(!1),D(!0),F(!0),p(null)},ae=({name:m},{inputValue:L})=>{const C=Y=>L.length?Y.replace(new RegExp(L,"gi"),ce=>`<mark>${ce}</mark>`):Y;return e.jsx(I,{children:e.jsx(w,{children:e.jsx(Q,{size:4,children:e.jsx("span",{dangerouslySetInnerHTML:{__html:C(m)}})})})})};l.useEffect(()=>{document.querySelectorAll('[class*="pb_button_kit"][class*="_secondary"], .pb_button_kit_secondary_inline_enabled').forEach(L=>{const C=L;_?(C.style.backgroundColor="rgba(207, 162, 0, 0.05)",C.style.color="#e9873e",C.style.borderColor="transparent"):(C.style.backgroundColor="",C.style.color="",C.style.borderColor="")})},[_]);const q=m=>{B(m.target.value)},re=()=>{switch(s?"icon_only":a){case"icon_only":return e.jsx(pe,{className:_?g.OctButtonColor:"",icon:"arrow-up-from-bracket",onClick:A,variant:t||"secondary"});case"full":return e.jsx(f,{className:_?g.OctButtonColor:"",icon:"arrow-up-from-bracket",onClick:A,text:"Share "+n,variant:t||"secondary"});default:return e.jsx(f,{className:_?g.OctButtonColor:"",icon:"arrow-up-from-bracket",onClick:A,text:"Share",variant:t||"secondary"})}},ie=()=>s?g.ShareConfirmationToastListView:g.ShareConfirmationToast,z=()=>{let m="";return r&&(m+=`${r}
`),c?m+=`[${c}](${o})`:m+=`[${n}](${o})`,T&&(m+=`

${T}`),U?`${m}

u#all`:m};return e.jsxs(e.Fragment,{children:[S&&e.jsx(G,{className:ie(),closeable:!0,multiLine:!0,status:"success",text:"Success. You've shared this "+n+" on Connect."}),re(),e.jsx(I,{children:e.jsxs(v,{onClose:N,opened:se,size:"lg",children:[e.jsx(v.Header,{children:"Share "+n+" To:"}),e.jsx(f,{className:$?"":g.LinkButton,marginLeft:"sm",marginTop:"sm",onClick:oe,tabIndex:0,text:"Share with a person",variant:"secondary"}),e.jsx(f,{className:H?"":g.LinkButton,marginTop:"sm",onClick:ne,tabIndex:0,text:"Share in a room",variant:"secondary"}),$&&e.jsx(Ie,{buildMessage:z,error:x,handleMessageText:q,onCancel:N,postId:i,postType:d,selectedUser:k,setConfirmationToast:h,setError:p,setSelectedUser:y,toggleLgDialog:M,url:o,value:T}),H&&e.jsx(Te,{buildMessage:z,error:x,formatOptionLabel:ae,handleMessageText:q,onCancel:N,postId:i,postType:d,selectedRoom:E,setConfirmationToast:h,setError:p,setSelectedRoom:b,setWholeRoom:F,toggleLgDialog:M,url:o,value:T,wholeRoom:U})]},"lg")})]})};export{Z as C,Ke as O,ye as S,Ve as a,ve as u};
//# sourceMappingURL=index-BajEbCOM.js.map
