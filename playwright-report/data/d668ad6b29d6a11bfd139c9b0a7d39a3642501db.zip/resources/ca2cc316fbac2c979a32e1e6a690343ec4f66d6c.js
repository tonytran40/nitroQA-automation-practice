function u(n){return function(){return n}}var t=function(){};t.thatReturns=u;t.thatReturnsFalse=u(!1);t.thatReturnsTrue=u(!0);t.thatReturnsNull=u(null);t.thatReturnsThis=function(){return this};t.thatReturnsArgument=function(n){return n};var e=t;export{e};
//# sourceMappingURL=emptyFunction-CpOH_lPB.js.map
