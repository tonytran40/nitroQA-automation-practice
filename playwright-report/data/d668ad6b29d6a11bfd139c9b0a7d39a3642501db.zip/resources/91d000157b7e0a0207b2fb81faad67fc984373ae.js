import{b as r}from"./playbook-ui-Bo6HcHKg.js";const a=(o=!1)=>{const[t,e]=r.useState(o);return[t,()=>e(!t)]};export{a as u};
//# sourceMappingURL=useToggler-DlimAUdP.js.map
