import{j as s,U as m}from"./playbook-ui-Bo6HcHKg.js";import{l as t}from"./lodash-D-AsfB3s.js";import{g as l}from"./index-CgX5gCa4.js";const p=({photo:r,id:e,name:o,territory:a,title:i,active:n})=>s.jsx(m,{avatar:!0,avatarUrl:n&&t.get(r,"url",null),id:`option-user-${e}`,name:o,orientation:"horizontal",territory:t.get(a,"name"),title:t.get(i,"name")});p.fragments={user:l`
    fragment UserOptionEmployee on Employee {
      id
      photo { url }
      name
      territory {
        id
        name
      }
      title {
        id
        name
      }
      active
    }
  `};export{p as U};
//# sourceMappingURL=UserOption-LtQ1jPdz.js.map
