(window.webpackJsonp=window.webpackJsonp||[]).push([[28],{"0Cb+":function(e,t,a){"use strict";a.r(t),a.d(t,"usePermissions",(function(){return y}));var n=a("LvDl"),r=a("wap/"),i=a("lTCR"),o=a.n(i);const l=o.a`
  query usePermissions($permissions:[String!]!) {
    user {
      id
      permissions(permissions:$permissions)
    }
  }
`;o.a`
query($search: Json, $name: String) {
  featureToggles(search: $search) {
    enabledFor(name: $name)
  }
}
`;var s=Object.defineProperty,c=Object.defineProperties,u=Object.getOwnPropertyDescriptors,m=Object.getOwnPropertySymbols,d=Object.prototype.hasOwnProperty,p=Object.prototype.propertyIsEnumerable,g=(e,t,a)=>t in e?s(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a;const b=(e,t)=>Object(n.isArray)(t)?Object(n.reduce)(t,((t,a)=>[...t,e[a]]),[]):Object(n.reduce)(t,((t,a,n)=>{return r=((e,t)=>{for(var a in t||(t={}))d.call(t,a)&&g(e,a,t[a]);if(m)for(var a of m(t))p.call(t,a)&&g(e,a,t[a]);return e})({},t),i={[n]:e[a]},c(r,u(i));var r,i}),{});var h=a("q1tI");const f=e=>{const{data:t}=Object(r.a)(l,{variables:{permissions:Object.values(e).sort()},skip:Object(n.isEmpty)(e)});return Object(h.useMemo)((()=>b(Object(n.get)(t,"user.permissions",{}),e)),[t,e])};f.mock=e=>({request:{query:l,variables:{permissions:Object.keys(e).sort()}},result:{data:{user:{id:13,permissions:e,__typename:"Employee"}}}});var y=f},"2zRr":function(e,t,a){(t=a("JPst")(!0)).push([e.i,".styles__selectWidths___3Aj9L{width:100%}.styles__cardWidth___1GxiX{width:50%}.styles__cardBody___2h4MA{margin-bottom:-20px}","",{version:3,sources:["/home/app/src/components/directory/app/components/Region/styles.scss"],names:[],mappings:"AAAA,8BACE,UAAA,CAGF,2BACE,SAAA,CAGF,0BACE,mBAAA",file:"styles.scss",sourcesContent:[".selectWidths {\n  width: 100%;\n}\n\n.cardWidth {\n  width: 50%;\n}\n\n.cardBody {\n  margin-bottom: -20px;\n}\n\n"]}]),t.locals={selectWidths:"styles__selectWidths___3Aj9L",cardWidth:"styles__cardWidth___1GxiX",cardBody:"styles__cardBody___2h4MA"},e.exports=t},"8aAJ":function(e,t,a){var n=a("LboF"),r=a("Q/pn");"string"===typeof(r=r.__esModule?r.default:r)&&(r=[[e.i,r,""]]);var i={insert:"head",singleton:!1};n(r,i);e.exports=r.locals||{}},AJJw:function(e,t,a){"use strict";var n=a("q1tI"),r=a.n(n),i=a("BzwP"),o=a("OLee"),l=a("ZaqM"),s=a("LvDl"),c=a("ttZb"),u=a("lTCR");const m=a.n(u).a`
  query($search: Json) {
    users(search: $search) {
      list {
        id
        photo { url }
        name
        territory {
          id
          abbr
        }
        title {
          id
          name
        }
        role {
          id
          title
        }
        active
      }
    }
  }
`;var d=a("Jygt"),p=Object.defineProperty,g=Object.defineProperties,b=Object.getOwnPropertyDescriptors,h=Object.getOwnPropertySymbols,f=Object.prototype.hasOwnProperty,y=Object.prototype.propertyIsEnumerable,v=(e,t,a)=>t in e?p(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a,E=(e,t)=>{for(var a in t||(t={}))f.call(t,a)&&v(e,a,t[a]);if(h)for(var a of h(t))y.call(t,a)&&v(e,a,t[a]);return e};const O=e=>e.map((e=>{var t,a,n,r,i,o;return i=E({},e),o={label:e.name,value:e.id,photo:null==(t=null==e?void 0:e.photo)?void 0:t.url,territory:null==(a=null==e?void 0:e.territory)?void 0:a.abbr,title:null==(n=null==e?void 0:e.title)?void 0:n.name,role:null==(r=null==e?void 0:e.role)?void 0:r.title},g(i,b(o))})),_=e=>{var t=((e,t)=>{var a={};for(var n in e)f.call(e,n)&&t.indexOf(n)<0&&(a[n]=e[n]);if(null!=e&&h)for(var n of h(e))t.indexOf(n)<0&&y.call(e,n)&&(a[n]=e[n]);return a})(e,[]);return Object(i.fetchGraphqlOptions)({client:d.client,customSanitize:O,options:"users.list",query:m,playbook:!0,variables:e=>({search:E({active_eq:!0,preferred_full_name_cont:e},t)})})};var j=a("Crc7"),C=a.n(j);var P=({avatarUrl:e,name:t,role:a,territory:n,title:i})=>r.a.createElement("div",null,r.a.createElement(o.User,{avatar:!0,avatarUrl:e,name:t,territory:n,title:i}),r.a.createElement(o.Flex,{className:C.a.roleDetails,orientation:"row"},r.a.createElement(o.Body,{color:"light",display:"flex"},r.a.createElement(o.Tooltip,{alignItems:"center",placement:"top",text:"Role"},r.a.createElement(o.Icon,{icon:"user-tag",size:"xs"})),r.a.createElement(o.Badge,{className:C.a.badge,text:a}))));var w=({user:e})=>r.a.createElement(o.SelectableCard,{checked:!0,className:C.a.resultCard,inputId:`${e.name}_${e.id}`,name:e.name,padding:"sm",value:e.id},r.a.createElement(P,{avatarUrl:null==e?void 0:e.photo,name:null==e?void 0:e.name,role:null==e?void 0:e.role,territory:null==e?void 0:e.territory,title:null==e?void 0:e.title}));var A=({data:e,onSelect:t,selectedUserId:a})=>{const n=e=>{t(e.target.value)};return r.a.createElement("div",null,e.map(((e,t)=>{var i,l,s,c;return r.a.createElement(o.SelectableCard,{checked:e.id==a,className:C.a.resultCard,inputId:`${e.name}_${e.id}`,key:t,name:e.name,onChange:n,padding:"sm",value:e.id},r.a.createElement(P,{avatarUrl:null==(i=null==e?void 0:e.photo)?void 0:i.url,name:null==e?void 0:e.name,role:null==(l=null==e?void 0:e.role)?void 0:l.title,territory:null==(s=null==e?void 0:e.territory)?void 0:s.abbr,title:null==(c=null==e?void 0:e.title)?void 0:c.name}))})))},k=a("ZTbR"),x=Object.defineProperty,S=Object.defineProperties,D=Object.getOwnPropertyDescriptors,T=Object.getOwnPropertySymbols,I=Object.prototype.hasOwnProperty,B=Object.prototype.propertyIsEnumerable,$=(e,t,a)=>t in e?x(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a,q=(e,t)=>{for(var a in t||(t={}))I.call(t,a)&&$(e,a,t[a]);if(T)for(var a of T(t))B.call(t,a)&&$(e,a,t[a]);return e};var F=({onHide:e})=>{const{start:t}=Object(n.useContext)(k.a),[a,i]=Object(n.useState)([]),[u,d]=Object(n.useState)(!1),[p,g]=Object(n.useState)(),[b,h]=Object(n.useState)(""),[f,y]=Object(n.useState)([]),[v,E]=Object(n.useState)([]),[O,j]=Object(n.useState)([]),[x]=Object(c.useLazyQuery)(m,{fetchPolicy:"no-cache",notifyOnNetworkStatusChange:!0,onCompleted:e=>{d(!1),i(Object(s.get)(e,"users.list",[])),h(Object(s.get)(e,"users.list[0].id",""))}}),T=q(q(q({},f.length>0&&{user_title_id_ins:f}),v.length>0&&{territory_id_in:v}),O.length>0&&{department_id_in:O}),I=Object(n.useCallback)(Object(s.debounce)(x,350),[]),B=p?p.id:b;return Object(n.useEffect)((()=>{if(Object(s.isEmpty)(T))return i([]),void h("");var e,t;d(!0),I({variables:{search:(e=q({},T),t={active_eq:!0},S(e,D(t)))}})}),[f,v,O]),r.a.createElement(o.Flex,{align:"stretch",className:C.a.resultsContainer,orientation:"column",padding:"sm"},r.a.createElement(o.FlexItem,{className:C.a.filters},r.a.createElement(o.Typeahead,{async:!0,cacheOptions:!1,defaultOptions:!1,label:"Employee",loadOptions:Object(s.debounce)(_(T),350),onChange:e=>g(e),placeholder:"Search Employees",valueComponent:e=>r.a.createElement(P,{avatarUrl:null==e?void 0:e.photo,name:null==e?void 0:e.name,role:null==e?void 0:e.role,territory:null==e?void 0:e.territory,title:null==e?void 0:e.title})}),r.a.createElement(o.Typeahead,{async:!0,isMulti:!0,label:"Title",loadOptions:Object(s.debounce)(Object(l.fetchUserTitleOptions)({playbook:!0},!0),350),multiKit:f.length>2?"badge":"smallPill",onChange:e=>y(e?e.map((e=>e.id)):[]),placeholder:"Search Titles"}),r.a.createElement(o.Typeahead,{async:!0,isMulti:!0,label:"Territory",loadOptions:Object(s.debounce)(Object(l.fetchTerritoryOptions)({playbook:!0},!0),350),multiKit:v.length>2?"badge":"smallPill",onChange:e=>E(e?e.map((e=>e.id)):[]),placeholder:"Search Territories"}),r.a.createElement(o.Typeahead,{async:!0,isMulti:!0,label:"Department",loadOptions:Object(s.debounce)(Object(l.fetchDepartmentOptions)({playbook:!0},!0),350),marginBottom:"xs",multiKit:O.length>2?"badge":"smallPill",onChange:e=>j(e?e.map((e=>e.id)):[]),placeholder:"Search Departments"})),r.a.createElement(o.FlexItem,{className:C.a.results,grow:!0},!B&&r.a.createElement(o.Flex,{align:"center",className:C.a.noResultsText,justify:"center",orientation:"column"},u&&r.a.createElement(o.LoadingInline,{align:"center"}),!u&&r.a.createElement(o.Caption,{color:"light",size:"xs",text:Object(s.isEmpty)(T)?"Search for someone to impersonate":"No results found"})),p&&r.a.createElement(w,{user:p}),!p&&b&&r.a.createElement(A,{data:a,onSelect:h,selectedUserId:b})),r.a.createElement(o.FlexItem,{className:C.a.footerButtons},r.a.createElement(o.Flex,{align:"center",justify:"between"},r.a.createElement(o.Button,{disabled:!B,icon:"user-secret",onClick:()=>{t(B).then((()=>{window.location.href="/"}))},text:"Impersonate"}),r.a.createElement(o.Button,{onClick:e,text:"Cancel",variant:"link"}))))};t.a=({visible:e,onHide:t})=>r.a.createElement(i.FullPageModalFlyout,{className:C.a.flyout,onExit:t,onHide:t,position:"right",show:e},r.a.createElement(o.Flex,{alignItems:"stretch",className:C.a.flyoutContent,orientation:"column"},r.a.createElement(o.Flex,{align:"center",justify:"between",padding:"sm"},r.a.createElement(o.FlexItem,null,r.a.createElement(o.Title,{size:4,text:"Impersonate Directory"})),r.a.createElement(o.FlexItem,null,r.a.createElement(o.CircleIconButton,{icon:"times",onClick:t,variant:"link"}))),r.a.createElement(o.SectionSeparator,null),r.a.createElement(F,{onHide:t})))},"Az2+":function(e,t,a){"use strict";a.r(t),a.d(t,"fetchUserTitleOptions",(function(){return y})),a.d(t,"fetchUserTitleTypeOptions",(function(){return E})),a.d(t,"fetchDepartmentOptions",(function(){return O})),a.d(t,"fetchBranchOptions",(function(){return _})),a.d(t,"fetchBusinessUnitOptions",(function(){return j})),a.d(t,"fetchDivisionOptions",(function(){return C})),a.d(t,"fetchTerritoryOptions",(function(){return P})),a.d(t,"fetchUserOptions",(function(){return w})),a.d(t,"fetchOfficeLocationOptions",(function(){return A}));var n=a("lTCR"),r=a.n(n),i=a("BzwP"),o=a("Jygt"),l=a("8MAY"),s=Object.defineProperty,c=Object.defineProperties,u=Object.getOwnPropertyDescriptors,m=Object.getOwnPropertySymbols,d=Object.prototype.hasOwnProperty,p=Object.prototype.propertyIsEnumerable,g=(e,t,a)=>t in e?s(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a,b=(e,t)=>{for(var a in t||(t={}))d.call(t,a)&&g(e,a,t[a]);if(m)for(var a of m(t))p.call(t,a)&&g(e,a,t[a]);return e},h=(e,t)=>c(e,u(t)),f=(e,t)=>{var a={};for(var n in e)d.call(e,n)&&t.indexOf(n)<0&&(a[n]=e[n]);if(null!=e&&m)for(var n of m(e))t.indexOf(n)<0&&p.call(e,n)&&(a[n]=e[n]);return a};const y=(e={})=>{var t=e,{fields:a=[],playbook:n=!1,through:l}=t,s=f(t,["fields","playbook","through"]);return Object(i.fetchGraphqlOptions)({client:o.client,playbook:n,query:r.a`
    query($search: Json, $through: String) {
      options: userTitles(search: $search, through: $through) {
        id
        name
        active
        ${a.join(" ")}
      }
    }
  `,variables:e=>({through:l,search:b({name_cont:e},s)})})},v=e=>e.map((e=>({id:e,name:Object(i.humanize)(e),label:Object(i.humanize)(e),value:e}))),E=({playbook:e=!1,includeVendorsAndBots:t=!1}={})=>Object(i.fetchGraphqlOptions)({client:o.client,playbook:e,filterByValue:!0,query:r.a`
    query($includeVendorsAndBots: Boolean = false){
      options: userTitleTypes(includeVendorsAndBots: $includeVendorsAndBots)
    }
  `,variables:()=>({includeVendorsAndBots:t}),customSanitize:v}),O=(e={})=>{var t=e,{through:a,playbook:n=!1}=t,l=f(t,["through","playbook"]);return Object(i.fetchGraphqlOptions)({client:o.client,playbook:n,query:r.a`
    query($search: Json, $through: String) {
      options: departments(search: $search, through: $through) {
        id
        name
      }
    }
  `,variables:e=>({through:a,search:b({name_cont:e},l)})})},_=(e={})=>{var t=e,{through:a,playbook:n=!1,customSanitizer:l=null}=t,s=f(t,["through","playbook","customSanitizer"]);return!Object.keys(s).some((e=>e.startsWith("status")))&&(s=Object.assign({status_eq:"open"},s)),Object(i.fetchGraphqlOptions)({client:o.client,playbook:n,query:r.a`
        query($search: Json, $through: String) {
          options: branches(search: $search, through: $through) {
            id
            name
            territory { id }
          }
        }
      `,variables:e=>({through:a,search:b({branch_name_cont:e},s)}),customSanitize:l})},j=(e={})=>{var t=e,{playbook:a=!1}=t,n=f(t,["playbook"]);return Object(i.fetchGraphqlOptions)({client:o.client,playbook:a,query:r.a`
    query($search: Json) {
      options: businessUnits(search: $search) {
        id
        name
      }
    }
  `,variables:e=>({search:h(b({},n),{name_cont:e})})})},C=(e={})=>{var t=e,{playbook:a=!1}=t,n=f(t,["playbook"]);return Object(i.fetchGraphqlOptions)({client:o.client,playbook:a,query:r.a`
    query($search: Json) {
      options: divisions(search: $search) {
        id
        name
      }
    }
  `,variables:e=>({search:h(b({},n),{name_cont:e})})})},P=(e={})=>{var t=e,{through:a,playbook:n=!1}=t,l=f(t,["through","playbook"]);return!Object.keys(l).some((e=>e.startsWith("status")))&&(l=Object.assign({status_eq:"open"},l)),Object(i.fetchGraphqlOptions)({client:o.client,playbook:n,query:r.a`
        query($search: Json, $through: String) {
          options: territories(search: $search, through: $through) {
            id
            name
          }
        }
      `,variables:e=>({through:a,search:h(b({},l),{name_cont:e})})})},w=(e={},t=!1,a=null,n=null)=>{var s=e,{through:c,accessibleBy:u}=s,m=f(s,["through","accessibleBy"]);return Object(i.fetchGraphqlOptions)({client:o.client,query:r.a`
    query($search: Json, $through: String, $accessibleBy: String) {
      users(search: $search, through: $through, accessibleBy: $accessibleBy) {
        list {
          ...UserOptionEmployee
        }
      }
    }
    ${n||l.default.fragments.user}
  `,variables:e=>({through:c,accessibleBy:u,search:b({substring_lookup:e},m)}),options:"users.list",playbook:t,customSanitize:a})},A=(e={})=>{var t=e,{playbook:a=!1}=t,n=f(t,["playbook"]);return Object(i.fetchGraphqlOptions)({client:o.client,playbook:a,query:r.a`
    query fetchOfficeLocationOptions($search: Json) {
      options: officeLocations(search: $search) {
        id
        name
        status
      }
    }
  `,variables:e=>({search:b({name_cont:e},n)})})}},"C/sa":function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),i=a("Jygt"),o=a("BzwP"),l=a("OLee"),s=(e,t,a)=>new Promise(((n,r)=>{var i=e=>{try{l(a.next(e))}catch(t){r(t)}},o=e=>{try{l(a.throw(e))}catch(t){r(t)}},l=e=>e.done?n(e.value):Promise.resolve(e.value).then(i,o);l((a=a.apply(e,t)).next())}));var c=({daysTilPassphraseExpiration:e,nitroIdUrl:t})=>{const[a,i]=Object(n.useState)(!0),[c,u]=Object(n.useState)(""),{isInLandscapeMode:m}=Object(o.useDeviceMediaChecks)(),d=`Your account security is our top priority. Your passphrase is set to expire in ${e} ${e>1?"days":"day"}. Act now to update it and keep it protected.`,p=()=>s(void 0,null,(function*(){return(yield fetch("/directory/passphrase_expiration_warning_dismissed",{method:"POST",body:JSON.stringify({}),headers:Object(o.authenticityHeaders)()})).ok})),g=()=>s(void 0,null,(function*(){if(c)return;u("skip");(yield p())&&i(!1)}));return r.a.createElement(r.a.Fragment,null,r.a.createElement(l.Flex,null,r.a.createElement(l.Dialog,{key:"passphrase-expiration-warning-modal",onClose:g,opened:a,size:"md"},r.a.createElement(l.Dialog.Body,null,r.a.createElement(l.Flex,{align:"center",orientation:"column"},r.a.createElement(l.IconCircle,{icon:"key",size:"md",variant:"royal"}),r.a.createElement(l.Title,{paddingTop:"sm",size:3,tag:"h3",text:"Passphrase Update Required",textAlign:"center"}),r.a.createElement(l.Body,{paddingTop:"sm",text:d,textAlign:"center"}))),r.a.createElement(l.Dialog.Footer,{paddingBottom:m?"md":"none",paddingX:"md"},r.a.createElement(l.Button,{fullWidth:!0,loading:"redirect"===c,marginBottom:m?"none":"sm",onClick:()=>s(void 0,null,(function*(){if(c)return;u("redirect");(yield p())&&(window.location.href=t)}))},"Yes, Change Now"),m&&r.a.createElement(l.Button,{fullWidth:!0,marginLeft:"md",onClick:g,variant:"link"},"Skip for Now")),!m&&r.a.createElement(l.Dialog.Footer,{paddingBottom:"md",paddingTop:"none",paddingX:"md"},r.a.createElement(l.Button,{fullWidth:!0,onClick:g,variant:"link"},"Skip for Now")))))};t.default=({daysTilPassphraseExpiration:e,nitroIdUrl:t})=>r.a.createElement(i.GraphqlProvider,null,r.a.createElement(c,{daysTilPassphraseExpiration:e,nitroIdUrl:t}))},CI4E:function(e,t,a){var n=a("LboF"),r=a("2zRr");"string"===typeof(r=r.__esModule?r.default:r)&&(r=[[e.i,r,""]]);var i={insert:"head",singleton:!1};n(r,i);e.exports=r.locals||{}},Crc7:function(e,t,a){var n=a("LboF"),r=a("nRfs");"string"===typeof(r=r.__esModule?r.default:r)&&(r=[[e.i,r,""]]);var i={insert:"head",singleton:!1};n(r,i);e.exports=r.locals||{}},J976:function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),i=a("Jygt"),o=a("AJJw"),l=a("ZTbR");var s=({show:e,onHide:t})=>{const a=Object(l.b)("/sessions/api/impersonation");return r.a.createElement(i.GraphqlProvider,null,r.a.createElement(l.a.Provider,{value:a},r.a.createElement(o.a,{onHide:t,visible:e})))},c=Object.defineProperty,u=Object.defineProperties,m=Object.getOwnPropertyDescriptors,d=Object.getOwnPropertySymbols,p=Object.prototype.hasOwnProperty,g=Object.prototype.propertyIsEnumerable,b=(e,t,a)=>t in e?c(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a,h=(e,t)=>{for(var a in t||(t={}))p.call(t,a)&&b(e,a,t[a]);if(d)for(var a of d(t))g.call(t,a)&&b(e,a,t[a]);return e},f=(e,t)=>u(e,m(t));t.default=()=>{return e=void 0,t=null,a=function*(){const{impersonating:e}=yield fetch("/sessions/api/impersonation").then((e=>e.json())),t={tags:["user"],gravity:0,icon:"user-secret"};return f(h({},t),e?{label:"Stop Impersonating",url:"/sessions/api/impersonation/end",meta:{color:"error"}}:{label:"Impersonate",modal:s})},new Promise(((n,r)=>{var i=e=>{try{l(a.next(e))}catch(t){r(t)}},o=e=>{try{l(a.throw(e))}catch(t){r(t)}},l=e=>e.done?n(e.value):Promise.resolve(e.value).then(i,o);l((a=a.apply(e,t)).next())}));var e,t,a}},Kw7S:function(e,t,a){"use strict";a.r(t);var n=a("WA7+"),r=a.n(n),i=a("q1tI"),o=a.n(i),l=a("OLee"),s=a("TSYQ"),c=a.n(s),u=Object.defineProperty,m=Object.defineProperties,d=Object.getOwnPropertyDescriptors,p=Object.getOwnPropertySymbols,g=Object.prototype.hasOwnProperty,b=Object.prototype.propertyIsEnumerable,h=(e,t,a)=>t in e?u(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a,f=(e,t)=>{for(var a in t||(t={}))g.call(t,a)&&h(e,a,t[a]);if(p)for(var a of p(t))b.call(t,a)&&h(e,a,t[a]);return e},y=(e,t)=>m(e,d(t));t.default=({reset:e=!1,pwnedToggle:t})=>{const[a,n]=Object(i.useState)(""),[s,u]=Object(i.useState)(""),[m,d]=Object(i.useState)(""),[p,g]=Object(i.useState)(!1),[b,h]=Object(i.useState)(!1),[v,E]=Object(i.useState)({label:"",percent:0,score:0,variant:""}),O=s===m,_=!(0===m.length)&&!O,j=_?"Passphrases do not match":"\xa0",C=!O||v.score<3,P=c()("fullwidth-mobile",e&&C?"dark-disabled-fullwidth-fix":null);return Object(i.useEffect)((()=>{const e=(e=>{const{passphrase:t="",common:a=!1,isPwned:n=!1,averageThreshold:i=2,minLength:o=12,strongThreshold:l=3}=e,s={variant:"negative",label:"",percent:0},c={variant:"negative",label:"This passphrase is too common",percent:25},u={variant:"negative",label:"Too weak",percent:25},m={variant:"warning",label:"Almost there, keep going!",percent:50},d={variant:"positive",label:"Success! Strong passphrase",percent:100},{score:p}=r()(t),g=t.length<=0,b=a||n,h=t.length<o||p<i,v=p<l,E=p>=l;return g?y(f({},s),{score:p}):b?y(f({},c),{score:p}):h?y(f({},u),{score:p}):v?y(f({},m),{score:p}):E?y(f({},d),{score:p}):void 0})({passphrase:s});E(f({},e))}),[s]),o.a.createElement(o.a.Fragment,null,!e&&o.a.createElement(l.Passphrase,{confirmation:!0,inputProps:{autoComplete:"new-password",error:b,id:"user_old_password",name:"user[old_password]",placeholder:"Old Passphrase",required:!0},label:"Old Passphrase",marginBottom:"xl",onChange:e=>n(e.target.value),value:a}),o.a.createElement(l.Passphrase,{checkPwned:t,dark:e,inputProps:{autoComplete:"new-password",id:"user_password",name:"user[password]",placeholder:"New Passphrase",minLength:12,required:!0},label:"New Passphrase",onChange:e=>u(e.target.value),value:s}),s.length>0&&o.a.createElement(o.a.Fragment,null,o.a.createElement(l.ProgressSimple,{percent:v.percent,variant:v.variant}),o.a.createElement(l.Caption,{size:"xs",text:v.label})),o.a.createElement(l.Passphrase,{confirmation:!0,dark:e,inputProps:{autoComplete:"new-password",id:"user_password_confirmation",error:_,name:"user[password_confirmation]",pattern:".{12,}",placeholder:"Confirm Passphrase",minLength:12,required:!0},label:"Confirm Passphrase",marginBottom:"xs",marginTop:"md",onChange:e=>d(e.target.value),value:m}),o.a.createElement(l.Body,{marginBottom:"xs",status:"negative",text:j}),o.a.createElement(l.Button,{className:P,disabled:C,fullWidth:e,htmlType:"submit",loading:p,onClick:t=>{e||0!==a.length?(t.preventDefault(),g(!0),h(!1),t.currentTarget.form.submit()):h(!0)},text:"Save Passphrase"}))}},No8v:function(e,t,a){"use strict";a.r(t),a.d(t,"LOCALITIES_QUERY",(function(){return s}));var n=a("q1tI"),r=a.n(n),i=a("OLee"),o=a("ttZb"),l=a("lTCR");const s=a.n(l).a`
  fragment LocalityItemFields on Locality {
    id
    label: name
    value: recordId
    level
    parentId
  }

  query localityTree(
    $skipBranchLevel: Boolean
    $fromDate: Date
    $toDate: Date
  ) {
    locality(
      skipBranchLevel: $skipBranchLevel
      fromDate: $fromDate
      toDate: $toDate
    ) {
      ...LocalityItemFields
      children {
        ...LocalityItemFields
        children {
          ...LocalityItemFields
        }
      }
    }
  }
`,c=e=>e.map((e=>e.id));t.default=({id:e,onChange:t,skipBranchLevel:a,fromDate:n,toDate:l,value:u})=>{const{loading:m,data:d}=Object(o.useQuery)(s,{variables:{skipBranchLevel:a,fromDate:n,toDate:l}});return m?null:r.a.createElement(i.MultiLevelSelect,{id:e,inputDisplay:"none",onSelect:t,returnAllSelected:!0,selectedIds:c(null!=u?u:[]),treeData:null==d?void 0:d.locality})}},"Q/pn":function(e,t,a){(t=a("JPst")(!0)).push([e.i,".styles__account_management_id_badge___3UO79{margin-left:50px}","",{version:3,sources:["/home/app/src/components/directory/app/components/UserAccountManagement/styles.scss"],names:[],mappings:"AAAA,6CACE,gBAAA",file:"styles.scss",sourcesContent:[".account_management_id_badge {\n  margin-left: 50px;\n}\n"]}]),t.locals={account_management_id_badge:"styles__account_management_id_badge___3UO79"},e.exports=t},ZTbR:function(e,t,a){"use strict";a.d(t,"b",(function(){return i}));var n=a("q1tI"),r=a.n(n);function i(e){const[t,a]=Object(n.useState)(!1);return Object(n.useEffect)((()=>{fetch(e).then((e=>e.json())).then((({impersonating:e})=>a(e)))}),[]),{impersonating:t,end:()=>fetch(e,{method:"DELETE"}),start:t=>fetch(e,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:t})})}}t.a=r.a.createContext({})},ZaqM:function(e,t,a){"use strict";var n=a("TqRt");Object.defineProperty(t,"__esModule",{value:!0});var r={CommonPassphraseManagementApp:!0,DirectoryManagementApp:!0,NewPassphraseFormApp:!0,UserAccountManagementApp:!0,UserOption:!0,ImpersonationApp:!0,ImpersonationMenuItem:!0,LocalitySelect:!0,RegionApp:!0,PassphraseExpirationWarningsApp:!0,TestController:!0};Object.defineProperty(t,"CommonPassphraseManagementApp",{enumerable:!0,get:function(){return o.default}}),Object.defineProperty(t,"DirectoryManagementApp",{enumerable:!0,get:function(){return l.default}}),Object.defineProperty(t,"ImpersonationApp",{enumerable:!0,get:function(){return m.default}}),Object.defineProperty(t,"ImpersonationMenuItem",{enumerable:!0,get:function(){return d.default}}),Object.defineProperty(t,"LocalitySelect",{enumerable:!0,get:function(){return p.default}}),Object.defineProperty(t,"NewPassphraseFormApp",{enumerable:!0,get:function(){return s.default}}),Object.defineProperty(t,"PassphraseExpirationWarningsApp",{enumerable:!0,get:function(){return b.default}}),Object.defineProperty(t,"RegionApp",{enumerable:!0,get:function(){return g.default}}),Object.defineProperty(t,"TestController",{enumerable:!0,get:function(){return h.default}}),Object.defineProperty(t,"UserAccountManagementApp",{enumerable:!0,get:function(){return c.default}}),Object.defineProperty(t,"UserOption",{enumerable:!0,get:function(){return u.default}});var i=a("Az2+");Object.keys(i).forEach((function(e){"default"!==e&&"__esModule"!==e&&(Object.prototype.hasOwnProperty.call(r,e)||e in t&&t[e]===i[e]||Object.defineProperty(t,e,{enumerable:!0,get:function(){return i[e]}}))}));var o=n(a("rcIq")),l=n(a("fl48")),s=n(a("Kw7S")),c=n(a("dH/p")),u=n(a("8MAY")),m=n(a("zBxo")),d=n(a("J976")),p=n(a("No8v")),g=n(a("fJmg")),b=n(a("C/sa"));a("olHM");var h=n(a("lijn"))},"dH/p":function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),i=a("Jygt"),o=a("OLee"),l=a("6mWV"),s=a.n(l),c=a("lTCR"),u=a.n(c),m=a("LvDl"),d=a("ttZb"),p=a("BzwP"),g=a("8aAJ"),b=a.n(g);var h=({user:e})=>{const t=e=>({contactType:"email",contactValue:e});return r.a.createElement("tr",null,r.a.createElement("td",null,r.a.createElement(o.User,{avatar:!0,avatarUrl:e.photo?e.photo.url:null,name:e.name,size:"sm",territory:Object(m.get)(e,"territory.abbr"),title:Object(m.get)(e,"title.name")}),r.a.createElement(o.Badge,{className:b.a.account_management_id_badge,text:e.id,variant:"neutral"})),r.a.createElement("td",{align:"center"},r.a.createElement(o.Pill,{text:"unlocked",variant:"neutral"})),r.a.createElement("td",null,r.a.createElement(o.PersonContact,{contacts:(e=>{const a=e.phoneNumbers.map((e=>(e=>({contactType:e.numberType.toLowerCase(),contactValue:e.number,contactDetail:e.numberType}))(e)));return a.unshift(t(e.email)),e.emailAlt2&&a.unshift(t(e.emailAlt2)),a})(e)})),r.a.createElement("td",null,r.a.createElement(o.HomeAddressStreet,{address:e.address1,addressCont:e.address2,city:e.city,state:e.state,zipcode:e.zip})))},f=a("KYPV"),y=a("ZaqM");var v=({filters:e,onChange:t,onReset:a})=>{return r.a.createElement(o.Filter,{filters:(n=e,{User:Object(m.map)(n,"name").join(",")}),paddingBottom:"sm"},r.a.createElement(f.Formik,{enableReinitialize:!0,initialValues:e,onReset:a,onSubmit:t},(({handleSubmit:e,handleReset:t})=>r.a.createElement("form",{onReset:t,onSubmit:e},r.a.createElement(f.Field,{component:p.TypeaheadFormik,defaultOptions:[],label:"User",loadOptions:Object(y.fetchUserOptions)({active_eq:!0},!0),name:"id_in"}),r.a.createElement(o.Flex,{justify:"between"},r.a.createElement(o.Button,{htmlType:"submit",text:"Apply",variant:"primary"}),r.a.createElement(o.Button,{htmlType:"reset",text:"Reset",variant:"secondary"}))))));var n};const E=u.a`
  query($page: Int!, $perPage: Int!, $search: Json) {
    employees(page: $page, perPage: $perPage, search: $search) {
      list {
        photo {
          url
        }
        id
        name
        territory {
          abbr
        }
        title {
          name
        }
        address1
        address2
        city
        state
        zip
        email
        emailAlt2
        phoneNumbers {
          number
          numberType
        }
      }
      page
      perPage
      totalEntries
    }
  }
`,O={},_=e=>({id_in:Object(m.map)(e,"id")});var j=()=>{const[e,t,a]=Object(p.useLocalStorage)("user-account-management.nitro.filter",O),[i,l]=Object(n.useState)(0),{data:c,loading:u,refetch:g}=Object(d.useQuery)(E,{fetchPolicy:"no-cache",variables:{page:i+1,perPage:20,search:_(e)}}),f=Object(m.get)(c,"employees.list",[]),y=Object(m.get)(c,"employees",{}),j=Math.ceil(y.totalEntries/y.perPage)||1;if(u&&!c)return r.a.createElement(p.Loading,null);return r.a.createElement("div",null,r.a.createElement(s.a,{activeClassName:"active",breakClassName:"break-me",breakLabel:"...",containerClassName:"pagination",forcePage:i,marginPagesDisplayed:2,onPageChange:({selected:e})=>l(e),pageCount:j,pageRangeDisplayed:5}),r.a.createElement(v,{filters:e,onChange:e=>{t(e),l(0),g()},onReset:a}),r.a.createElement(o.Table,null,r.a.createElement("thead",null,r.a.createElement("tr",null,r.a.createElement("th",{className:b.a.account_management_id_badge},"User"),r.a.createElement("th",{align:"center"},"Account Status"),r.a.createElement("th",null,"Contact Info"),r.a.createElement("th",null,"Address"))),r.a.createElement("tbody",null,f.map((e=>r.a.createElement(h,{key:`user-row-${e.id}`,user:e}))))))};var C=()=>r.a.createElement(r.a.Fragment,null,r.a.createElement(o.Title,{paddingBottom:"sm",size:2,tag:"h1",text:"User Account Management"}),r.a.createElement(j,null));t.default=()=>r.a.createElement(i.GraphqlProvider,null,r.a.createElement(C,null))},fJmg:function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),i=a("Jygt"),o=a("NKCw"),l=a("ttZb"),s=a("LvDl"),c=a("OLee");var u=({inactiveTerritories:e})=>r.a.createElement(r.a.Fragment,null,r.a.createElement(c.Card,{marginTop:"md",padding:"sm"},r.a.createElement(c.Caption,{text:"Inactive Territories"}),e.map(((e,t)=>r.a.createElement("div",{key:`territory-${t}`},r.a.createElement(c.Card,{marginY:"xxs",paddingX:"sm",paddingY:"xs"},r.a.createElement(c.Flex,{justify:"between"},r.a.createElement(c.Title,{color:"light",marginTop:"sm",size:4,text:e.label}),r.a.createElement(c.Flex,{gap:"sm"},r.a.createElement(c.DatePicker,{defaultDate:e.effectiveDate,disableInput:!0,hideLabel:!0,marginBottom:"none",pickerId:`date-picker-inactive-territory-effective-date-${t}`}),r.a.createElement(c.DatePicker,{defaultDate:e.endDate,disableInput:!0,hideLabel:!0,marginBottom:"none",pickerId:`date-picker-inactive-territory-end-date-${t}`}))))))))),m=Object.defineProperty,d=Object.defineProperties,p=Object.getOwnPropertyDescriptors,g=Object.getOwnPropertySymbols,b=Object.prototype.hasOwnProperty,h=Object.prototype.propertyIsEnumerable,f=(e,t,a)=>t in e?m(e,t,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[t]=a,y=(e,t)=>{for(var a in t||(t={}))b.call(t,a)&&f(e,a,t[a]);if(g)for(var a of g(t))h.call(t,a)&&f(e,a,t[a]);return e},v=(e,t)=>d(e,p(t));var E=({effectiveDate:e,endDate:t,formType:a,region:i,register:o,setValue:l,regionTerritories:s,territoryOptions:u})=>{o("regionTerritories");const[m,d]=Object(n.useState)(s),[p,g]=Object(n.useState)(e),[b,h]=Object(n.useState)(t),f=e=>{const t=e.effectiveDate&&new Date(e.effectiveDate)<new Date,a=i&&!i.regionTerritoryOptions.some((t=>t.value.toString()===e.territoryId.toString()));return t&&a},E=(e,t)=>{const n="effectiveDate"===t?e.effectiveDate:e.endDate;return"New"===a||"Edit"===a&&i.regionTerritories.includes(e)?n:""};return Object(n.useEffect)((()=>{g(e),h(t)}),[e,t,l]),r.a.createElement(r.a.Fragment,null,r.a.createElement(c.Card,null,r.a.createElement(c.Typeahead,{isMulti:!0,label:"Available Territories",onChange:e=>{var t;if(e!==m){const a=(null==(t=null==i?void 0:i.regionTerritories)?void 0:t.map((e=>e.territoryId.toString())))||[],n=e.filter((e=>!a.includes(e.value))).map((e=>({territoryId:e.value,label:e.label,effectiveDate:p,endDate:b})));d([...(null==i?void 0:i.regionTerritories)||[],...n]),l("regionTerritories",n)}},options:u,placeholder:"Add a territory"})),m&&m.map(((e,t)=>r.a.createElement("div",{key:`territory-${t}`},r.a.createElement(c.Card,{marginY:"xxs",padding:"sm"},r.a.createElement(c.Flex,{justify:"between"},r.a.createElement(c.Title,{marginTop:"sm",size:4,text:e.label}),r.a.createElement(c.Flex,{gap:"sm"},r.a.createElement(c.DatePicker,{blankSelection:"Select Start Date",defaultDate:E(e,"effectiveDate"),disableInput:f(e),hideLabel:!0,marginBottom:"none",name:`effectiveDate-${t}`,onChange:e=>((e,t)=>{const a=[...m];a[t]=v(y({},a[t]),{effectiveDate:e}),d(a),l("regionTerritories",a)})(e,t),pickerId:`date-picker-region-territory-effective-date-${t}`}),r.a.createElement(c.DatePicker,{blankSelection:"Select End Date",defaultDate:E(e,"endDate"),hideLabel:!0,marginBottom:"none",name:`endDate-${t}`,onChange:e=>((e,t)=>{const a=[...m];a[t]=v(y({},a[t]),{endDate:e}),d(a),l("regionTerritories",a)})(e,t),pickerId:`date-picker-region-territory-end-date-${t}`}))))))))},O=a("ZaqM");const _={active_eq:!0,title_name_in:["Sr. Vice President of Contact Center","Sr. Vice President of Project Services","Sr. Vice President of People","Regional Sr. Vice President of Sales","Regional Sr. Vice President of Customer Development","Regional Sr. Vice President of Delivery"]};var j=({defaultValue:e,onChange:t})=>r.a.createElement(c.Typeahead,{async:!0,defaultValue:e,isMulti:!0,label:"Region SVPs",loadOptions:Object(s.debounce)(Object(O.fetchUserOptions)(_,!0),350),onChange:t,placeholder:"Select...",valueComponent:e=>{var t;return r.a.createElement(c.User,{avatar:!0,avatarUrl:null==(t=null==e?void 0:e.photo)?void 0:t.url,key:`employee-${e.id}`,name:e.name})}}),C=a("lTCR"),P=a.n(C);const w=P.a`
  query territories {
    territories {
      id
      name
    }
  }
`,A=P.a`
  mutation($input: RegionInput!) {
    upsertRegion(input: $input) {
      id
      name
      effectiveDate
      regionTerritories {
        territoryId
      }
      regionRsvps {
        rsvpId
      }
    }
  }
`;var k=a("CI4E"),x=a.n(k);var S=({formType:e,region:t})=>{var a;const[i,m]=Object(n.useState)(null),[d,p]=Object(n.useState)(t?t.effectiveDate:""),[g,b]=Object(n.useState)(t?t.endDate:""),[h,f]=Object(n.useState)(t?t.regionRsvps:[]),{data:y}=Object(l.useQuery)(w),v=Object(s.get)(y,"territories",[]).filter((e=>!t||t.regionTerritoryOptions.some((t=>t.value.toString()===e.id)))).map((e=>({label:e.name,value:e.id}))),[O,{error:_,loading:C}]=Object(l.useMutation)(A),P=e=>{const a=e=>({territoryId:"string"===typeof e.territoryId?parseInt(e.territoryId):e.territoryId,effectiveDate:""==e.effectiveDate?null:e.effectiveDate,endDate:e.endDate||null});return{id:e.id,name:e.name,effectiveDate:""==e.effectiveDate?null:e.effectiveDate,endDate:e.endDate||null,regionRsvps:[...(h||[]).map((e=>({regionId:e.regionId?e.regionId:null,rsvpId:e.rsvpId})))],regionTerritories:[...((null==t?void 0:t.regionTerritories)||[]).map((t=>{var n;const r=null==(n=e.regionTerritories)?void 0:n.find((e=>e.territoryId===t.territoryId));return a(r||t)})),...((null==t?void 0:t.inactiveTerritories)||[]).map((e=>a(e))),...(e.regionTerritories||[]).map((e=>{var n;return(null==(n=null==t?void 0:t.regionTerritories)?void 0:n.some((t=>t.territoryId===e.territoryId)))?null:a(e)})).filter(Boolean)]}},k=e=>{return t=void 0,a=null,n=function*(){yield O({variables:{input:P(e)}})},new Promise(((e,r)=>{var i=e=>{try{l(n.next(e))}catch(t){r(t)}},o=e=>{try{l(n.throw(e))}catch(t){r(t)}},l=t=>t.done?e(t.value):Promise.resolve(t.value).then(i,o);l((n=n.apply(t,a)).next())}));var t,a,n},{handleSubmit:S,register:D,setValue:T,watch:I}=Object(o.useForm)({mode:"onSubmit",defaultValues:t||{id:"",name:"",effectiveDate:"",endDate:"",regionTerritories:[],regionRsvps:[]}}),B=(null==(a=null==t?void 0:t.regionRsvps)?void 0:a.map((e=>{var t,a;return{label:e.label,value:e.rsvpId,imageUrl:null==(a=null==(t=e.rsvp)?void 0:t.photo)?void 0:a.url}})))||[];return D("effectiveDate",{required:!0}),D("endDate"),Object(n.useEffect)((()=>{m(Object(s.get)(_,"networkError.result.error"))}),[_]),r.a.createElement(r.a.Fragment,null,i&&r.a.createElement(c.Flex,{justify:"center"},r.a.createElement(c.FixedConfirmationToast,{closeable:!0,horizontal:"center",marginBottom:"sm",multiLine:!0,status:"error",text:i})),r.a.createElement(c.Flex,{justify:"center",orientation:"row"},r.a.createElement(c.Card,{className:x.a.cardWidth,padding:"none"},r.a.createElement(c.Card.Body,{padding:"sm"},r.a.createElement(c.Title,{text:"New"==e?"Create Region":"Edit Region"})),r.a.createElement(c.SectionSeparator,{variant:"card"}),r.a.createElement("form",{onSubmit:S((e=>{k(e).then((()=>window.location.href="/directory/regions"))}))},r.a.createElement(c.Card.Body,{className:x.a.cardBody},r.a.createElement("input",{name:"id",ref:D,type:"hidden"}),r.a.createElement(c.TextInput,{label:"Region Name *"},r.a.createElement("input",{name:"name",placeholder:"Enter region name",ref:D()})),r.a.createElement(c.Flex,{gap:"sm"},r.a.createElement(c.DatePicker,{blankSelection:"Select Start Date",className:x.a.selectWidths,disableInput:(()=>{if(t){return t.effectiveDate&&new Date(t.effectiveDate)<new Date}return!1})(),format:"m/d/Y",inputValue:d,label:"Region Start Date *",marginBottom:"none",name:"effectiveDate",onChange:e=>{T("effectiveDate",e,{shouldValidate:!0}),p(e)},pickerId:"date-picker-region-effective-date"}),r.a.createElement(c.DatePicker,{blankSelection:"Select End Date",className:x.a.selectWidths,format:"m/d/Y",inputValue:g,label:"Region End Date",marginBottom:"none",name:"endDate",onChange:e=>{T("endDate",e,{shouldValidate:!0}),b(e)},pickerId:"date-picker-region-end-date"}))),r.a.createElement(c.SectionSeparator,{variant:"card"}),r.a.createElement(c.Card.Body,{marginY:"xs",padding:"sm"},r.a.createElement(c.Card,{background:"light",marginBottom:"sm"},r.a.createElement(E,{effectiveDate:I("effectiveDate"),endDate:I("endDate"),formType:e,region:t,regionTerritories:I("regionTerritories"),register:D,setValue:T,territoryOptions:v})),t&&!Object(s.isEmpty)(t.inactiveTerritories)&&r.a.createElement(u,{inactiveTerritories:t.inactiveTerritories}),r.a.createElement(j,{defaultValue:B,onChange:e=>{T("regionRsvps",e.map((e=>e.value))),f(e.map((e=>({rsvpId:Number(e.value),regionId:t?Number(t.id):null}))))},svps:[]})),r.a.createElement(c.SectionSeparator,{variant:"card"}),r.a.createElement(c.Card.Body,{padding:"sm"},r.a.createElement(c.Flex,{justify:"between",orientation:"row"},r.a.createElement(c.Button,{disabled:C,htmlType:"submit",loading:C,text:"New"==e?"Create":"Save",variant:"primary"}),r.a.createElement(c.Button,{onClick:()=>{window.location.href="/directory/regions"},text:"Cancel",variant:"secondary"})))))))};t.default=({formType:e,region:t})=>r.a.createElement(i.GraphqlProvider,null,r.a.createElement(S,{formType:e,region:t}))},fl48:function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),i=a("55Ip"),o=a("Jygt"),l=a("Ty5D"),s=a("LvDl"),c=a("OLee"),u=a("ttZb"),m=a("lTCR"),d=a.n(m),p=a("BzwP");const g=({businessUnit:e,children:t,company:a,title:n})=>r.a.createElement(r.a.Fragment,null,r.a.createElement(p.NavigationHeader,{size:2,title:n},r.a.createElement(p.Breadcrumbs,null,r.a.createElement(p.BreadcrumbsItem,null,r.a.createElement(i.Link,{to:"/"},"Companies")),a&&r.a.createElement(p.BreadcrumbsItem,null,r.a.createElement(i.Link,{to:`/companies/${Object(s.get)(a,"id")}`},Object(s.get)(a,"name"))),e&&r.a.createElement(p.BreadcrumbsItem,null,r.a.createElement(i.Link,{to:`/business_units/${Object(s.get)(e,"id")}`},Object(s.get)(e,"name"))))),r.a.createElement(c.Flex,{className:"container",grow:"true",justify:"left"},r.a.createElement(c.Card,{display:"inline",highlight:{position:"side",color:"warning"},padding:"sm",shadow:"deep"},"Want to add/edit something? Visit the ",r.a.createElement("a",{href:"/directory/org_levels"},"Org Levels page"),".")),r.a.createElement("div",{className:"container"},t));g.fragments={businessUnit:d.a`
    fragment ManagementNavigationBusinessUnit on BusinessUnit {
      id
      name
    }
  `,company:d.a`
    fragment ManagementNavigationCompany on Company {
      id
      name
    }
  `};var b=g;const h=({businessUnit:e})=>r.a.createElement("tr",null,r.a.createElement("td",null,r.a.createElement(i.Link,{to:`/business_units/${e.id}`},e.name)),r.a.createElement("td",null,e.active?"Yes":"No"));h.fragments={businessUnit:d.a`
    fragment BusinessUnitRowBusinessUnit on BusinessUnit {
      id
      name
      active
    }
  `};var f=h;const y=d.a`
  query ($companyId: ID!) {
    company(id: $companyId) {
      id
      ...ManagementNavigationCompany
      businessUnits {
        id
        ...BusinessUnitRowBusinessUnit
      }
    }
  }
  ${b.fragments.company}
  ${f.fragments.businessUnit}
`;var v=()=>{const{companyId:e}=Object(l.useParams)(),{data:t,loading:a}=Object(u.useQuery)(y,{variables:{companyId:e},fetchPolicy:"network-only"});return r.a.createElement(b,{company:Object(s.get)(t,"company"),title:Object(s.get)(t,"company.name")},r.a.createElement(c.Flex,{className:"mt-4 mb-4",justify:"between"},r.a.createElement(c.Title,{size:3,text:"Business Units"})),r.a.createElement(c.Table,{size:"md"},r.a.createElement("thead",null,r.a.createElement("tr",null,r.a.createElement("th",null,"Name"),r.a.createElement("th",null,"Active"))),r.a.createElement("tbody",null,r.a.createElement(p.LoadingList,{list:Object(s.get)(t,"company.businessUnits",[]),loading:a,tableContainer:!0},(e=>r.a.createElement(f,{businessUnit:e,key:`business-unit-${e.id}`}))))))};const E=({company:e})=>r.a.createElement("tr",null,r.a.createElement("td",null,r.a.createElement(i.Link,{to:`/companies/${e.id}`},e.name)),r.a.createElement("td",null,e.active?"Yes":"No"));E.fragments={company:d.a`
    fragment CompanyRowCompany on Company {
      id
      name
      active
    }
  `};var O=E;const _=d.a`
  query {
    companies {
      id
      ...CompanyRowCompany
    }
  }
  ${O.fragments.company}
`;var j=()=>{const{data:e,loading:t}=Object(u.useQuery)(_);return r.a.createElement(b,{title:"Companies"},r.a.createElement(c.Flex,{className:"mt-4 mb-4",justify:"between"},r.a.createElement(c.Title,{size:3,text:"Companies"})),r.a.createElement(c.Table,{size:"md"},r.a.createElement("thead",null,r.a.createElement("tr",null,r.a.createElement("th",null,"Name"),r.a.createElement("th",null,"Active"))),r.a.createElement("tbody",null,r.a.createElement(p.LoadingList,{list:Object(s.get)(e,"companies",[]),loading:t,tableContainer:!0},(e=>r.a.createElement(O,{company:e,key:`company-${e.id}`}))))))};const C=({division:e})=>r.a.createElement("tr",null,r.a.createElement("td",null,e.name),r.a.createElement("td",null,e.active?"Yes":"No"),r.a.createElement("td",null,e.businessUnit.name));C.fragments={division:d.a`
    fragment DivisionRowDivision on Division {
      id
      name
      active
      businessUnit {
        id
        name
      }
    }
  `};var P=C;const w=d.a`
  query($id: ID!) {
    businessUnit(id: $id) {
      id
      ...ManagementNavigationBusinessUnit
      company {
        ...ManagementNavigationCompany
      }
      divisions {
        id
        ...DivisionRowDivision
      }
    }
  }
  ${b.fragments.businessUnit}
  ${b.fragments.company}
  ${P.fragments.division}
`;var A=()=>{const{businessUnitId:e}=Object(l.useParams)(),{data:t,loading:a}=Object(u.useQuery)(w,{variables:{id:e},fetchPolicy:"network-only"});return r.a.createElement(b,{businessUnit:Object(s.get)(t,"businessUnit"),company:Object(s.get)(t,"businessUnit.company"),title:Object(s.get)(t,"businessUnit.name")},r.a.createElement(c.Flex,{className:"mt-4 mb-4",justify:"between"},r.a.createElement(c.Title,{size:3,text:"Divisions"})),r.a.createElement(c.Table,{size:"md"},r.a.createElement("thead",null,r.a.createElement("tr",null,r.a.createElement("th",null,"Name"),r.a.createElement("th",null,"Active"),r.a.createElement("th",null,"Business Unit"))),r.a.createElement("tbody",null,r.a.createElement(p.LoadingList,{list:Object(s.get)(t,"businessUnit.divisions",[]),loading:a,tableContainer:!0},(e=>r.a.createElement(P,{division:e,key:`division-${e.id}`}))))))};var k=()=>r.a.createElement(l.Switch,null,r.a.createElement(l.Route,{component:j,exact:!0,path:"/"}),r.a.createElement(l.Route,{component:v,exact:!0,path:"/companies/:companyId"}),r.a.createElement(l.Route,{component:A,exact:!0,path:"/business_units/:businessUnitId"}));t.default=({basename:e})=>r.a.createElement(o.GraphqlProvider,null,r.a.createElement(i.BrowserRouter,{basename:e},r.a.createElement(k,null)))},lijn:function(e,t,a){"use strict";var n=a("TqRt");Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r=n(a("lwsE")),i=n(a("W8MJ")),o=n(a("7W2i")),l=n(a("a1gu")),s=n(a("Nsbk"));function c(e){var t=function(){if("undefined"===typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"===typeof Proxy)return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],(function(){}))),!0}catch(e){return!1}}();return function(){var a,n=(0,s.default)(e);if(t){var r=(0,s.default)(this).constructor;a=Reflect.construct(n,arguments,r)}else a=n.apply(this,arguments);return(0,l.default)(this,a)}}var u=function(e){(0,o.default)(a,e);var t=c(a);function a(){return(0,r.default)(this,a),t.apply(this,arguments)}return(0,i.default)(a,[{key:"connect",value:function(){console.log("test controller connected in directory")}},{key:"greet",value:function(){console.log("hello world")}},{key:"disconnect",value:function(){console.log("test controller disconnected")}}]),a}(a("AJ0d").Controller);t.default=u,u.targets=["name"]},nRfs:function(e,t,a){(t=a("JPst")(!0)).push([e.i,".styles__flyoutContent___2GyBX{height:100%}.styles__resultsContainer___2WFJi{height:100%;overflow:scroll}.styles__filters___2Xc6m input{width:100% !important}.styles__footerButtons___2dbK0{padding-top:15px}.styles__results___CkPpi{overflow:auto}.styles__flyout___bX2Nv [class^=modal-dialog]{min-width:45vw;height:100vh;height:-webkit-fill-available}.styles__roleDetails___2DXWZ{padding-left:54px}.styles__resultCard___2EkLL label{margin-bottom:8px !important}.styles__noResultsText___1--i8{height:100%}.styles__badge___qq5V-{border:none !important}","",{version:3,sources:["/home/app/src/components/directory/app/components/ImpersonationFlyout/styles.scss"],names:[],mappings:"AAAA,+BACE,WAAA,CAGF,kCACE,WAAA,CACA,eAAA,CAGF,+BACE,qBAAA,CAGF,+BACE,gBAAA,CAGF,yBACE,aAAA,CAIA,8CACE,cAAA,CACA,YAAA,CACA,6BAAA,CAIJ,6BACE,iBAAA,CAGF,kCACE,4BAAA,CAGF,+BACE,WAAA,CAGF,uBACE,sBAAA",file:"styles.scss",sourcesContent:[".flyoutContent {\n  height: 100%;\n}\n\n.resultsContainer {\n  height: 100%;\n  overflow: scroll;\n}\n\n.filters input {\n  width: 100% !important;\n}\n\n.footerButtons {\n  padding-top: 15px;\n}\n\n.results {\n  overflow: auto;\n}\n\n.flyout {\n  [class^=modal-dialog] {\n    min-width: 45vw;\n    height: 100vh;\n    height: -webkit-fill-available;\n  }\n}\n\n.roleDetails {\n  padding-left: 54px;\n}\n\n.resultCard label {\n  margin-bottom: 8px !important;\n}\n\n.noResultsText {\n  height: 100%;\n}\n\n.badge {\n  border: none !important;\n}\n"]}]),t.locals={flyoutContent:"styles__flyoutContent___2GyBX",resultsContainer:"styles__resultsContainer___2WFJi",filters:"styles__filters___2Xc6m",footerButtons:"styles__footerButtons___2dbK0",results:"styles__results___CkPpi",flyout:"styles__flyout___bX2Nv",roleDetails:"styles__roleDetails___2DXWZ",resultCard:"styles__resultCard___2EkLL",noResultsText:"styles__noResultsText___1--i8",badge:"styles__badge___qq5V-"},e.exports=t},olHM:function(e,t,a){"use strict";var n=a("TqRt"),r=a("AJ0d"),i=n(a("lijn"));window.Stimulus=r.Application.start(),Stimulus.register("test",i.default)},rcIq:function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),i=a("Jygt"),o=a("6mWV"),l=a.n(o),s=a("OLee"),c=a("frVR"),u=a("KYPV"),m=a("BzwP");const d=Object(m.withFormik)(s.TextInput);var p=({initialValues:e,onSubmit:t,onCancel:a,loading:n})=>r.a.createElement(u.Formik,{initialValues:e,onSubmit:t},(({handleSubmit:e})=>r.a.createElement("form",{onSubmit:e},r.a.createElement(s.Caption,{text:"Passphrase"}),r.a.createElement(u.Field,{component:d,name:"entry",placeholder:"New Passphrase"}),r.a.createElement(s.Flex,{justify:"between"},r.a.createElement(s.Button,{disabled:n,htmlType:"submit",loading:n,text:"Save",variant:"primary"}),r.a.createElement(s.Button,{onClick:a,text:"Cancel",variant:"secondary"})))));var g=({show:e,onHide:t,onCreate:a,loading:n})=>r.a.createElement(c.a,{onHide:t,show:e},r.a.createElement(c.a.Title,{text:"Create New Passphrase"}),r.a.createElement(c.a.Body,null,r.a.createElement(p,{loading:n,onCancel:t,onSubmit:a}))),b=a("lTCR"),h=a.n(b),f=a("LvDl"),y=a("ttZb");const v=h.a`
  mutation($id: ID!){
    deleteCommonPassphrase(id: $id)
  }
`;var E=({passphrase:e,refetch:t,permissions:a})=>{const[i,o]=Object(n.useState)(!1),[l]=Object(y.useMutation)(v);return r.a.createElement(r.a.Fragment,null,r.a.createElement("tr",null,r.a.createElement("td",null,e.entry),r.a.createElement("td",{align:"right"},a.common_passphrase_management&&a.common_passphrase_management.manage&&r.a.createElement(s.Button,{loading:i,onClick:()=>{o(!0),l({variables:{id:e.id}}).then(t).then((()=>{o(!1)}))},text:"Delete",variant:"secondary"}))))};const O=h.a`
  query {
    user {
      id
      permissions
    }
  }
`,_=h.a`
  query($page: Int!, $perPage: Int!){
    commonPassphrases(page: $page, perPage: $perPage){
      list {
        id
        entry
      }
      page
      perPage
      totalEntries
    }
  }
`,j=h.a`
  mutation($input: CommonPassphraseInput!) {
    createCommonPassphrase(input: $input) {
      entry
    }
  }
`;var C=()=>{const[e,t]=Object(n.useState)(0),{data:a,loading:i,refetch:o}=Object(y.useQuery)(_,{variables:{page:e+1,perPage:20}}),[c,u]=Object(n.useState)(!1),[d,p]=Object(m.useToggler)(),[b]=Object(y.useMutation)(j),{data:h}=Object(y.useQuery)(O),v=Object(f.get)(h,"user.permissions",""),C=Object(f.get)(a,"commonPassphrases.list",[]),P=Object(f.get)(a,"commonPassphrases",{}),w=Math.ceil(P.totalEntries/P.perPage)||1;return i?r.a.createElement(m.Loading,null):r.a.createElement(r.a.Fragment,null,r.a.createElement(s.Flex,{justify:"between"},r.a.createElement(s.Title,{text:"Common Passphrase Management"}),v.common_passphrase_management&&v.common_passphrase_management.manage&&r.a.createElement(s.Button,{onClick:p,text:"Add Passphrase"})),r.a.createElement(l.a,{activeClassName:"active",breakClassName:"break-me",breakLabel:"...",containerClassName:"pagination",forcePage:e,marginPagesDisplayed:2,onPageChange:({selected:e})=>t(e),pageCount:w,pageRangeDisplayed:5}),r.a.createElement(s.Table,{size:"sm"},r.a.createElement("thead",null,r.a.createElement("tr",null,r.a.createElement("th",null,"Entries"),r.a.createElement("th",{align:"right"},""))),r.a.createElement("tbody",null,C.map(((e,t)=>r.a.createElement(E,{key:t,passphrase:e,permissions:v,refetch:o}))))),r.a.createElement(g,{loading:c,onCreate:e=>{u(!0),b({variables:{input:e}}).then((()=>{o().then((()=>{p(),u(!1)}))}))},onHide:p,show:d}))};t.default=()=>r.a.createElement(i.GraphqlProvider,null,r.a.createElement(C,null))},zBxo:function(e,t,a){"use strict";a.r(t);var n=a("q1tI"),r=a.n(n),i=a("Jygt"),o=a("AJJw"),l=a("0Cb+"),s=a("OLee"),c=a("ZTbR");const u=({onShowImpersonate:e})=>{const[t]=Object(l.usePermissions)(["impersonation/impersonate"]),{impersonating:a,end:i}=Object(n.useContext)(c.a),o=()=>{i().then((()=>window.location.href="/"))};return a?r.a.createElement("li",null,r.a.createElement("a",{className:"text-danger",onClick:o},r.a.createElement(s.Icon,{fixedWidth:!0,icon:"user-secret"}),"End Impersonation")):t?r.a.createElement("li",null,r.a.createElement("a",{onClick:e},r.a.createElement(s.Icon,{fixedWidth:!0,icon:"user-secret"}),"Impersonate")):null};t.default=({impersonationUrl:e})=>{const t=Object(c.b)(e),[a,l]=Object(n.useState)(!1);return r.a.createElement(i.GraphqlProvider,null,r.a.createElement(c.a.Provider,{value:t},r.a.createElement(u,{onShowImpersonate:e=>{l(!0),e.stopPropagation()}}),r.a.createElement(o.a,{onHide:()=>l(!1),visible:a})))}}}]);