import{g as e}from"./index-CgX5gCa4.js";const s=e`
  query ($search: Json) {
    powerlifeEmployeeSearch(search: $search) {
      nodes {
        id
        name
      }
    }
  }
`,o=e`
  query ($search: Json) {
    connectRoomSearch(search: $search) {
      id
      name
    }
  }
`;e`
  query ($postId: ID!, $type: String!) {
    powerlifePostAsset(postId: $postId, type: $type) {
      id
      filename
      url
    }
  }
`;const a=e`
  query ($query: String) {
    powerlifeTags(query: $query) {
      id
      name
    }
  }
`;export{o as C,s as E,a as G};
//# sourceMappingURL=queries-Cf2FMXHP.js.map
