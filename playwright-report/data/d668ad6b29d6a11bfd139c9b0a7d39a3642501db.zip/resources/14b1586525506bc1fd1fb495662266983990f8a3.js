const r=e=>(e||"").replace(/\D/g,""),c=(e,a="$1-$2-$3")=>r(e).replace(/(\d{3})(\d{3})(\d{4})/g,a),s=e=>(e.charAt(0).toUpperCase()+e.slice(1)).replaceAll("_"," ");export{r as d,c as f,s as h};
//# sourceMappingURL=formatters-DMCnB84y.js.map
